#/usr/bin/python

from setuptools import setup
setup(	name='norsexml',
		version='0.1',
		description='Bla bla bla',
		author='Nikolaos Papadopoulos',
		author_email='papadopn@in.tum.de',
		py_modules=['norsexml'],
		requires=['argparse', 'lxml'])